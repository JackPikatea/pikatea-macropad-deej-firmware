# ShiroMicro
ProMicro clone with Mid-Mount USB Type-C connector
