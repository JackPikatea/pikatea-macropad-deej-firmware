Pro Micro library for KiCAD
=======================================

This repo includes Pro Micro library.
